// OfficeZen DataStore preferences (local-only app preferences)
package com.example.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "officezen_prefs")

class AppPreferences(private val context: Context) {
  val languageCodeFlow: Flow<String> =
    context.dataStore.data.map { prefs -> prefs[KEY_LANGUAGE_CODE] ?: "en" }

  val remindersEnabledFlow: Flow<Boolean> =
    context.dataStore.data.map { prefs -> prefs[KEY_REMINDERS_ENABLED] ?: true }

  val lastNotifiedMonthFlow: Flow<String> =
    context.dataStore.data.map { prefs -> prefs[KEY_LAST_NOTIFIED_MONTH] ?: "" }

  val localUserNameFlow: Flow<String> =
    context.dataStore.data.map { prefs -> prefs[KEY_LOCAL_USER_NAME] ?: "Office Owner" }

  val preferInitialsAvatarFlow: Flow<Boolean> =
    context.dataStore.data.map { prefs -> prefs[KEY_PREFER_INITIALS_AVATAR] ?: false }

  val lastSyncEpochMsFlow: Flow<Long> =
    context.dataStore.data.map { prefs -> prefs[KEY_LAST_SYNC_EPOCH_MS] ?: 0L }

  val lastSyncMessageFlow: Flow<String> =
    context.dataStore.data.map { prefs -> prefs[KEY_LAST_SYNC_MESSAGE] ?: "" }

  suspend fun setLanguageCode(code: String) {
    context.dataStore.edit { prefs -> prefs[KEY_LANGUAGE_CODE] = code }
  }

  suspend fun setRemindersEnabled(enabled: Boolean) {
    context.dataStore.edit { prefs -> prefs[KEY_REMINDERS_ENABLED] = enabled }
  }

  suspend fun setLastNotifiedMonth(monthKey: String) {
    context.dataStore.edit { prefs -> prefs[KEY_LAST_NOTIFIED_MONTH] = monthKey }
  }

  suspend fun setLocalUserName(name: String) {
    context.dataStore.edit { prefs -> prefs[KEY_LOCAL_USER_NAME] = name.trim().ifBlank { "Office Owner" } }
  }

  suspend fun setPreferInitialsAvatar(preferInitials: Boolean) {
    context.dataStore.edit { prefs -> prefs[KEY_PREFER_INITIALS_AVATAR] = preferInitials }
  }

  suspend fun setLastSyncResult(epochMs: Long, message: String) {
    context.dataStore.edit { prefs ->
      prefs[KEY_LAST_SYNC_EPOCH_MS] = epochMs
      prefs[KEY_LAST_SYNC_MESSAGE] = message.take(240)
    }
  }

  private companion object {
    val KEY_LANGUAGE_CODE = stringPreferencesKey("language_code")
    val KEY_REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
    val KEY_LAST_NOTIFIED_MONTH = stringPreferencesKey("last_notified_month")
    val KEY_LOCAL_USER_NAME = stringPreferencesKey("local_user_name")
    val KEY_PREFER_INITIALS_AVATAR = booleanPreferencesKey("prefer_initials_avatar")
    val KEY_LAST_SYNC_EPOCH_MS = longPreferencesKey("last_sync_epoch_ms")
    val KEY_LAST_SYNC_MESSAGE = stringPreferencesKey("last_sync_message")
  }
}
