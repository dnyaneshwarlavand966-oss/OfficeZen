# OfficeZen — Automated Firebase & APK Final Delivery Plan

This plan details the fully automated verification, zero-manual-secret CI configuration, and signed Debug APK preparation for **OfficeZen** (`officezen-d42ad`, Firestore database `officezen-db` in `asia-south1`, Android package `com.aistudio.officezen.kzmrxp`), using every official build, Firebase, and verification tool available in this environment without modifying existing UI, features, or user data.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Defaults Applied (Clarifying Questions Dismissed)**:
> - **Target Delivery Scope**: Execute end-to-end local verification across Firebase configuration, zero-trust security rules, emulator rule tests, Gradle unit tests, and signed Debug APK compilation.
> - **GitHub Workflow & Secrets Mode**: Keep the GitHub Actions Debug APK pipeline automatic-first—using the synced Firebase Android configuration directly when present (requiring zero manual GitHub secret entry after AI Studio Push to GitHub) while preserving `GOOGLE_SERVICES_JSON` secret fallback if excluded.
> - **Signing & Live Verification Scope**: Verify the APK signing certificate against the Firebase Android configuration locally and deliver clear, factual verification status.

> [!WARNING]
> **Platform Authorization Boundaries (What Cannot Bypass External Permissions)**:
> This execution environment does not have your GitHub OAuth token, a local Git remote repository, an Android Emulator/ADB bridge, or Firebase Console IAM console access to overwrite already-provisioned Android OAuth fingerprints after the retry cap. Accordingly:
> - **Automated Locally**: Config alignment, security rules audit & deployment call, emulator & Robolectric test suites, CI preflight checks, and signed Debug APK build.
> - **Requires Your One-Click Authorization Outside the Sandbox**: Clicking **Push to GitHub** in AI Studio (`dnyaneshwarlavand966-oss/OfficeZen`), confirming the debug SHA-1 fingerprint (`3C:DD:F7:13:8F:12:F1:3E:A4:BC:10:1F:00:C9:0E:25:79:AA:25:1F`) in Firebase Console if Google Sign-In rejects the debug build, and installing the APK on a real device to test live Google Sign-In.

---

## 1. Overview & Core Concept

- **What It Does**: Executes a complete automated pre-release audit and build pipeline for OfficeZen using official Gradle, Android Build Tools, Firebase Emulator, and AI Studio Firebase RPC tools.
- **Target Audience**: Project owner wanting zero unnecessary manual setup steps and an honest, verified final delivery package.
- **Key Value**: Eliminates silent Firebase mismatches, validates all Create/Join Office and security boundaries against real Firestore rule evaluation, and guarantees the synced workspace builds a ready-to-run Debug APK cleanly.

---

## 2. User Experience & Visual Design

- **Zero UI or Feature Changes**: All OfficeZen Compose screens, 22-language localization, payroll rules, attendance flows, and existing design tokens remain 100% untouched.
- **Resilient Auth & Error Experience**: Preserves Credential Manager Google Sign-In (`GetSignInWithGoogleOption` + timed `GetGoogleIdOption`), non-blocking Firestore timeouts, inline onboarding error feedback, and Retry / Switch Workspace controls when backend or network conditions block loading.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Zero-Friction Synced Config + Secret Fallback in CI**
  - *Chosen Approach*: Configure the GitHub Actions Debug APK workflow to accept the synced Firebase Android configuration directly when present in the repository, and fall back seamlessly to the `GOOGLE_SERVICES_JSON` repository secret only if missing—validating project ID (`officezen-d42ad`), database ID (`officezen-db`), package ID, and OAuth web client presence before invoking Gradle.
  - *Why*: Lets a single **Push to GitHub** from AI Studio trigger a passing GitHub Actions APK build without requiring manual secret copy-paste, while still supporting secret-based overrides.
  - *Alternatives Considered*: Requiring manual GitHub Secrets setup on every build (unnecessary manual friction when Firebase config is already synced) or skipping config validation (risks broken Google Sign-In in CI APKs).

- **Decision 2 — Strict Truthfulness Over Simulated Verification**
  - *Chosen Approach*: Run every check via real official tools (Firebase CLI emulator, Robolectric Firebase SDK tests, Android SDK `apksigner`, Gradle build, and AI Studio `DeployRules` RPC) and report exact tool boundaries without simulating remote GitHub pushes or live device sign-ins.
  - *Why*: Prevents false confidence about unexecuted remote steps and pinpoints exact certificate hashes (`debug.keystore` vs Firebase OAuth entry) immediately.

---

## 4. Technical Architecture & Data Strategy

### Automated Verification & Delivery Pipeline

```
┌──────────────────────────────────────────────────────────────────────────┐
│                 Stage 1: Official Configuration & Rules Audit            │
│  Firebase Project (`officezen-d42ad`) · Named DB (`officezen-db`)        │
│  Zero-Trust Rules Check (0 Open Rules) · Credential & Hardcode Scan      │
└────────────────────────────────────┬─────────────────────────────────────┘
                                     │
┌────────────────────────────────────▼─────────────────────────────────────┐
│                 Stage 2: Automated Emulator & Unit Verification          │
│  Firebase Auth + Firestore Emulator ─▶ JS Security Rules Suite (6 Tests) │
│  Robolectric + Real Firestore SDK   ─▶ Create/Join & Role Suites (7 Tests)│
└────────────────────────────────────┬─────────────────────────────────────┘
                                     │
┌────────────────────────────────────▼─────────────────────────────────────┐
│                 Stage 3: Signed Debug APK & CI Readiness Check           │
│  Google Services Resource Gen ─▶ `default_web_client_id` Verified        │
│  Gradle Debug Build           ─▶ Signed APK + `apksigner` Cert Digest    │
│  CI Preflight Script Check    ─▶ Ready for AI Studio Push ─▶ GitHub CI   │
└──────────────────────────────────────────────────────────────────────────┘
```

### Verification Coverage & State Checks

- **Firebase & Auth Wiring**: Confirms Google Sign-In Web OAuth client generation, non-empty `officezen-db` named database resolution, and clean debug keystore parity between local builds and CI keystore decoding.
- **Non-Destructive Security Guarantee**: Existing `officezen-db` data and zero-trust Firestore security rules remain strictly intact—no test rules, no open permissions, and no synthetic UI changes.
- **Final Delivery Package**: Produces the verified local Debug APK metadata, exact `apksigner` certificate digest comparison, automated test pass counts, and clear separation between automated completed checks and external account actions.
