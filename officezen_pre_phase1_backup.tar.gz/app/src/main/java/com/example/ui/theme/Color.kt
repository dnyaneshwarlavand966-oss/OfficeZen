package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Corporate Blue & Crisp White Material 3 Palette
val BlueHeaderDeep = Color(0xFF0D47A1)
val BluePrimary = Color(0xFF1565C0)
val BlueRoyal = Color(0xFF1D4ED8)
val BlueAccent = Color(0xFF2563EB)
val BlueSoftBg = Color(0xFFEFF6FF)
val BlueContainer = Color(0xFFDBEAFE)
val BlueOnContainer = Color(0xFF1E3A8A)

val PaperCanvas = Color(0xFFF4F7FB)
val PureSurface = Color(0xFFFFFFFF)
val SoftStone = Color(0xFFEEF2F7)
val HairlineWarm = Color(0xFFE2E8F0)

val ObsidianInk = Color(0xFF0F172A)
val StoneMuted = Color(0xFF64748B)
val StoneSubtle = Color(0xFF94A3B8)

// Module Accent Colors (Clean Material Icons & Badges — Zero Emojis)
val ChaiTerracotta = Color(0xFFB45309)
val ChaiCream = Color(0xFFFEF3C7)
val ChaiInk = Color(0xFF78350F)

val EspressoBrown = Color(0xFF5D4037)
val EspressoBg = Color(0xFFEFEBE9)

val LedgerIndigo = Color(0xFF4338CA)
val LedgerIndigoBg = Color(0xFFE0E7FF)

val TeamCyan = Color(0xFF0284C7)
val TeamCyanBg = Color(0xFFE0F2FE)

val LeaveRose = Color(0xFFE11D48)
val LeaveRoseBg = Color(0xFFFFE4E6)

val ReportViolet = Color(0xFF7C3AED)
val ReportVioletBg = Color(0xFFEDE9FE)

val SettingsSlate = Color(0xFF475569)
val SettingsSlateBg = Color(0xFFF1F5F9)

// Semantic Status Colors
val StatusGreen = Color(0xFF059669)
val StatusGreenBg = Color(0xFFDCFCE7)
val StatusAmber = Color(0xFFD97706)
val StatusAmberBg = Color(0xFFFEF3C7)
val StatusRed = Color(0xFFDC2626)
val StatusRedBg = Color(0xFFFEE2E2)

// Theme Aliases for Existing Components
val PineDeep = BlueHeaderDeep
val PineNight = Color(0xFF0A367A)
val PineSoft = BlueContainer
val LimeSpark = Color(0xFFFFFFFF)
val LimeInk = BlueHeaderDeep

val ZenTeal = BluePrimary
val ZenTealDark = BlueHeaderDeep
val SaffronAmber = ChaiTerracotta
val SaffronRich = ChaiInk
val SaffronContainer = ChaiCream
val OnSaffronContainer = ChaiInk
val IndigoAccent = LedgerIndigo
val IndigoBg = LedgerIndigoBg
val HeroGradientStart = Color(0xFF0D47A1)
val HeroGradientMid = Color(0xFF1565C0)
val HeroGradientEnd = Color(0xFF1E88E5)

// Midnight Navy Dark Mode Palette
val DarkCanvas = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkHairline = Color(0xFF283548)
val DarkLimePrimary = Color(0xFF60A5FA)
val DarkPineContainer = Color(0xFF1E3A8A)
val DarkInk = Color(0xFFF1F5F9)
val DarkStoneMuted = Color(0xFF94A3B8)
